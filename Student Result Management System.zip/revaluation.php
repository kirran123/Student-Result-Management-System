<?php
$conn = new mysqli("localhost", "root", "", "result_system");
$msg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $reg = $_POST['reg_no'];
  $subject = $_POST['subject'];
  $reason = $_POST['reason'];
  $conn->query("INSERT INTO revaluation_requests (reg_no, subject, reason) VALUES ('$reg', '$subject', '$reason')");
  $msg = "Revaluation request submitted successfully.";
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Revaluation Request</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <div class="header-left">
      <img src="logo.jpg" alt="RIT Logo" class="logo">
      <h1>Ramco Institute of Technology</h1>
    </div>
  </header>
  <nav>
    <a href="index.php">Home</a>
    <a href="student.php">Student</a>
    <a href="staff.php">Staff</a>
    <a href="revaluation.php">Revaluation</a>
    <a href="contact.php">Contact</a>
  </nav>
  <div class="container">
    <h2>Revaluation Request Form</h2>
    <form method="post">
      <input name="reg_no" placeholder="Register Number" required>
      <input name="subject" placeholder="Subject Name" required>
      <textarea name="reason" placeholder="Reason for Revaluation" required></textarea>
      <button type="submit">Submit Request</button>
    </form>
    <?php if (!empty($msg)) echo "<p style='color: green;'>$msg</p>"; ?>
    <h3>Revaluation Rules</h3>
    <ul>
      <li>Revaluation can be applied only within 7 days from the result declaration.</li>
      <li>Only theory papers are eligible for revaluation.</li>
      <li>Students must submit valid reasons for the request.</li>
      <li>Fee per subject is ₹500.</li>
      <li>Once submitted, no cancellation will be permitted.</li>
    </ul>
  </div>
  <footer>
    <p>&copy; 2025 Ramco Institute of Technology | Student Result Management System</p>
  </footer>
</body>
</html>