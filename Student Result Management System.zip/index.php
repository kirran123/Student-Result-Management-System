<!DOCTYPE html>
<html>
<head>
  <title>Home - Student Result System</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <div class="header-left">
      <img src="logo.jpg" alt="RIT Logo" class="logo">
      <h1>Ramco Institute of Technology</h1>
    </div>
  </header>
  <nav>
    <a href="index.php">Home</a>
    <a href="student.php">Student</a>
    <a href="staff.php">Staff</a>
    <a href="revaluation.php">Revaluation</a>
    <a href="contact.php">Contact</a>
  </nav>
  <div class="container">
    <h2>Welcome to Ramco Institute Of Technology Student Result Management System</h2>
    <p>This portal allows students to view their academic results and staff to manage student marks and revaluation requests efficiently.</p>
    <h3>Mission</h3>
    <ul>
      <li>To offer higher education in Engineering and Technology with highest level of quality, Professionalism and ethical standards</li>
      <li>To equip the students with up-to-date knowledge in cutting-edge technologies, wisdom, creativity and passion for innovation, and life-long learning skills.</li>
      <li>To constantly motivate and involve the students and faculty members in the education process for continuously improving their performance to achieve excellence.</li>
    </ul>
    <h3>Vission</h3>
    <p>To evolve as an Institute of international repute in offering high-quality technical education, Research and extension programmes in order to create knowledgeable, professionally competent and skilled Engineers and Technologists capable of working in multi-disciplinary environment to cater to the societal needs.</p>
    <h3>About Ramco Institute of Technology</h3>
    <p>Ramco Institute of Technology is founded with a vision to impart high quality engineering education at an affordable cost. Under the able guidance of our Chairman Shri.P.R.Venketrama Raja, son of Shri P. R. Ramasubrahmaneya Rajha; distinguished professionals, academicians and education experts, we continually aim to revolutionize the learning environment by creating an enviable knowledge pool of engineering and technology graduates who are attuned to the current industry requirements.
Being part of the Ramco Group, which is well known for its qualitative and innovative brands not only in India but across the world, we are looked upon to set high standards in the education sector. True to its legacy, RIT has embarked on a mission to empower students with high-quality, accessible yet world-class engineering education and prepare these young minds for lifelong learning by creating and disseminating appropriate knowledge.</p>
    <h3>Departments</h3>
    <ul>
      <li>Civil Engineering</li>
<li>Computer Science & Engg</li>
<li>Electrical & Electronics Engg.</li>
<li>Electronics & Communication Engg.</li>
<li>Mechanical Engineering</li>
<li>B.Tech Artificial Intelligence and Data Science</li>
<li>B.Tech. Computer Science and Business Systems</li>
<li>B.Tech. Information Technology</li>
<li>Science & Humanities</li>
</ul>
  </div>
  <footer>
    <p>&copy; 2025 Ramco Institute of Technology | Student Result Management System</p>
  </footer>
</body>
</html>