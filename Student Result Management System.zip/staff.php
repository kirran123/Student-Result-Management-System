<?php
$conn = new mysqli("localhost", "root", "", "result_system");
$msg = "";
$loggedIn = false;
$results = null;
$reval = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $user = $_POST['username'];
  $pass = $_POST['password'];
  $res = $conn->query("SELECT * FROM staff WHERE username='$user' AND password='$pass'");
  if ($res->num_rows === 1) {
    $loggedIn = true;
    $results = $conn->query("SELECT * FROM results");
    $reval = $conn->query("SELECT * FROM revaluation_requests");
  } else {
    $msg = "Invalid login.";
  }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Staff Panel</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header><div class="header-left"><img src="logo.jpg" class="logo"><h1>Ramco Institute of Technology</h1></div></header>
<nav><a href="index.php">Home</a><a href="student.php">Student</a><a href="staff.php">Staff</a><a href="revaluation.php">Revaluation</a><a href="contact.php">Contact</a></nav>
<div class="container">
<h2>Staff Login</h2>
<p>Only authorized staff members are allowed to access student results and revaluation requests.</p>
<form method="post">
  <input name="username" placeholder="Username" required>
  <input type="password" name="password" placeholder="Password" required>
  <button type="submit">Login</button>
</form>
<?php
if (!empty($msg)) echo "<p style='color:red;'>$msg</p>";
if ($loggedIn) {
  echo "<h3>All Results</h3><table border='1'><tr><th>Reg No</th><th>Subject</th><th>Marks</th><th>Revaluation</th></tr>";
  while ($row = $results->fetch_assoc()) {
    echo "<tr><td>{$row['reg_no']}</td><td>{$row['subject']}</td><td>{$row['marks']}</td><td>{$row['revaluation_status']}</td></tr>";
  }
  echo "</table>";
  echo "<h3>Revaluation Requests</h3><table border='1'><tr><th>Reg No</th><th>Subject</th><th>Reason</th><th>Date</th></tr>";
  while ($row = $reval->fetch_assoc()) {
    echo "<tr><td>{$row['reg_no']}</td><td>{$row['subject']}</td><td>{$row['reason']}</td><td>{$row['submitted_at']}</td></tr>";
  }
  echo "</table>";
}
?>
</div>
<footer><p>&copy; 2025 Ramco Institute of Technology</p></footer>
</body>
</html>