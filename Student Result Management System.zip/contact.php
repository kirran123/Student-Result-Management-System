<!DOCTYPE html>
<html>
<head>
  <title>Contact Us</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
<header><div class="header-left"><img src="logo.jpg" class="logo"><h1>Ramco Institute of Technology</h1></div></header>
<nav><a href="index.php">Home</a><a href="student.php">Student</a><a href="staff.php">Staff</a><a href="revaluation.php">Revaluation</a><a href="contact.php">Contact</a></nav>
<div class="container">
<h2>Contact Us</h2>
<p>If you have any queries or face any issues with the system, please feel free to contact us.</p>
<ul>
  <li>Email: rit@ritrjpm.ac.in</li>
  <li>Phone: 04563 233400</li>
  <li>Address: Ramco Institute of Technology, Rajapalayam, Tamil Nadu, India</li>
  <li>Office Hours: 9:00 AM - 5:00 PM (Monday to Saturday)</li>
</ul>
</div>
<footer><p>&copy; 2025 Ramco Institute of Technology</p></footer>
</body>
</html>